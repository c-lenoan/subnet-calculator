
import sys
import ipaddress
import pygame
import asyncio

pygame.init()

'''
Partie 1/3 — Configuration et calcul des sous-réseaux
Cette première partie contient la configuration, les couleurs, les calculs IPv4 et la génération des lignes du tableau.
'''

# ==================================================
# CONFIGURATION
# ==================================================

WIDTH, HEIGHT = 1536, 1024
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Calculateur IPv4 - Sous-réseaux")

CLOCK = pygame.time.Clock()

FONT = pygame.font.SysFont("consolas", 18)
SMALL_FONT = pygame.font.SysFont("consolas", 15)
BINARY_TABLE_FONT = pygame.font.SysFont("consolas", 12)
TITLE_FONT = pygame.font.SysFont("consolas", 23, bold=True)

# Couleurs
BG = (9, 22, 42)
PANEL = (15, 33, 59)
PANEL_ALT = (21, 43, 73)
BORDER = (38, 72, 112)
WHITE = (218, 233, 255)
MUTED = (155, 184, 218)

BLUE = (39, 153, 255)
ORANGE = (255, 126, 42)
GREEN = (49, 211, 157)
RED = (255, 85, 95)

# ==================================================
# ÉTAT DU PROGRAMME
# ==================================================

network = ipaddress.ip_network("192.168.1.0/24")
original_prefix = network.prefixlen
current_prefix = original_prefix

input_text = "192.168.1.0/24"
input_active = False
error_message = ""

table_rows = []
scroll_offset = 0

# Positions des éléments de l'interface
#input_rect = pygame.Rect(233, 74, 347, 45)
input_rect = pygame.Rect(333, 74, 347, 45)
calculate_rect = pygame.Rect(694, 74, 181, 45)

binary_rect = pygame.Rect(29, 142, 1478, 330)
table_rect = pygame.Rect(29, 496, 1478, 494)

# Position du curseur et de la zone binaire
slider_track_rect = pygame.Rect(52, 227, 1430, 4)

# ==================================================
# FONCTIONS GRAPHIQUES
# ==================================================

def draw_text(surface, text, x, y, color=WHITE, font=FONT, center_x=None):
    image = font.render(str(text), True, color)

    if center_x is not None:
        x = center_x - image.get_width() // 2

    surface.blit(image, (int(x), int(y)))
    return image.get_rect(topleft=(int(x), int(y)))


def draw_panel(surface, rect, color=PANEL):
    pygame.draw.rect(surface, color, rect, border_radius=7)
    pygame.draw.rect(surface, BORDER, rect, 1, border_radius=7)


def draw_button(surface, rect, text, active=False):
    color = (18, 101, 210) if not active else (30, 130, 235)
    pygame.draw.rect(surface, color, rect, border_radius=7)
    pygame.draw.rect(surface, BLUE, rect, 1, border_radius=7)

    label = FONT.render(text, True, WHITE)
    surface.blit(
        label,
        (
            rect.centerx - label.get_width() // 2,
            rect.centery - label.get_height() // 2
        )
    )


# ==================================================
# CALCULS IPv4
# ==================================================

def get_usable_hosts(prefix):
    """
    Nombre d'hôtes attribuables dans un sous-réseau IPv4 classique.
    Les adresses réseau et broadcast sont exclues.
    """
    host_bits = 32 - prefix

    if host_bits < 2:
        return 0

    return (2 ** host_bits) - 2


def get_subnet_mask(prefix):
    return str(
        ipaddress.IPv4Network(f"0.0.0.0/{prefix}").netmask
    )


def get_binary_address(address):
    return "".join(
        format(int(octet), "08b")
        for octet in str(address).split(".")
    )


# ==================================================
# CHARGEMENT D'UN RÉSEAU
# ==================================================

def load_network_from_input():
    global network, original_prefix, current_prefix
    global error_message, scroll_offset

    try:
        parsed = ipaddress.ip_network(
            input_text.strip(),
            strict=False
        )

        if parsed.version != 4:
            raise ValueError("Seules les adresses IPv4 sont acceptées.")

        if parsed.prefixlen > 30:
            raise ValueError(
                "Le préfixe initial doit être compris entre /0 et /30."
            )

        network = parsed
        original_prefix = parsed.prefixlen
        current_prefix = original_prefix

        error_message = ""
        scroll_offset = 0

        rebuild_table()

    except ValueError as exc:
        error_message = str(exc)


# ==================================================
# CONSTRUCTION DU TABLEAU
# ==================================================

def rebuild_table():
    global table_rows, scroll_offset

    table_rows = []

    if current_prefix < original_prefix:
        return

    borrowed_bits = current_prefix - original_prefix
    usable_hosts = get_usable_hosts(current_prefix)

    for index, subnet in enumerate(
        network.subnets(new_prefix=current_prefix)
    ):
        if borrowed_bits > 0:
            combination = format(
                index, f"0{borrowed_bits}b"
            )
        else:
            combination = "—"

        first_host = (
            str(subnet.network_address + 1)
            if usable_hosts > 0 else "—"
        )

        last_host = (
            str(subnet.broadcast_address - 1)
            if usable_hosts > 0 else "—"
        )

        table_rows.append({
            "combination": combination,
            "network": str(subnet.network_address),
            "prefix": f"/{current_prefix}",
            "mask": str(subnet.netmask),
            "first_host": first_host,
            "last_host": last_host,
            "broadcast": str(subnet.broadcast_address),
            "hosts": usable_hosts,
        })

    scroll_offset = 0


'''
Partie 2/3 — Représentation binaire et curseur orange
Elle dessine les 32 bits de l’adresse IPv4, le masque binaire juste en dessous, les couleurs réseau/hôtes/bits empruntés et le curseur orange superposé à la limite entre les bits.
Cette partie utilise le préfixe initial comme limite de départ : les bits réseau restent bleus, les bits empruntés deviennent orange avec un X, et les bits hôtes restent verts. Le curseur orange se déplace au-dessus des rangées binaires et s’arrête à /30.
'''


# ==================================================
# REPRÉSENTATION BINAIRE
# ==================================================

def draw_binary_visual(surface):
    x, y, width, height = binary_rect
    draw_panel(surface, binary_rect)

    draw_text(
        surface,
        "Représentation binaire de l'adresse et du masque",
        x + 20, y + 13, WHITE, TITLE_FONT
    )

    address_bits = get_binary_address(network.network_address)
    mask_bits = "1" * current_prefix + "0" * (32 - current_prefix)

    # Disposition des 32 bits
    left = x + 23
    right = x + width - 23
    total_width = right - left
    bit_width = total_width / 32

    address_y = y + 114
    bit_height = 41
    mask_y = address_y + 58

    # Nombre de bits réseau, empruntés et hôtes
    borrowed_bits = current_prefix - original_prefix
    host_bits = 32 - current_prefix

    # Titres des trois zones
    network_center = left + (original_prefix * bit_width) / 2
    borrowed_center = (
        left + (original_prefix + current_prefix) * bit_width / 2
    )
    hosts_center = left + (current_prefix + 32) * bit_width / 2

    draw_text(
        surface,
        f"Réseau ({original_prefix} bits)",
        network_center - 80, y + 56, BLUE, SMALL_FONT
    )

    if borrowed_bits > 0:
        draw_text(
            surface,
            f"Bits empruntés ({borrowed_bits} bits)",
            borrowed_center - 105, y + 56, ORANGE, SMALL_FONT
        )

    draw_text(
        surface,
        f"Hôtes ({host_bits} bits)",
        hosts_center - 55, y + 56, GREEN, SMALL_FONT
    )

    # Accolade supérieure pour les zones
    def draw_bracket(start_bit, end_bit, color):
        bx1 = int(left + start_bit * bit_width)
        bx2 = int(left + end_bit * bit_width)
        by = y + 84

        if bx2 > bx1:
            pygame.draw.line(
                surface, color, (bx1, by), (bx2, by), 2
            )
            pygame.draw.line(
                surface, color, (bx1, by), (bx1, by + 9), 2
            )
            pygame.draw.line(
                surface, color, (bx2, by), (bx2, by + 9), 2
            )

    draw_bracket(0, original_prefix, BLUE)

    if borrowed_bits > 0:
        draw_bracket(original_prefix, current_prefix, ORANGE)

    draw_bracket(current_prefix, 32, GREEN)

    # Cases de bits d'adresse et de masque
    for i in range(32):
        bx = left + i * bit_width
        bit_rect = pygame.Rect(
            int(bx),
            address_y,
            max(1, int(bit_width - 2)),
            bit_height
        )

        if i < original_prefix:
            color = BLUE
            shown_bit = address_bits[i]
        elif i < current_prefix:
            color = ORANGE
            shown_bit = "X"
        else:
            color = GREEN
            shown_bit = address_bits[i]

        pygame.draw.rect(
            surface,
            color,
            bit_rect,
            border_radius=3
        )

        text = SMALL_FONT.render(shown_bit, True, WHITE)
        surface.blit(
            text,
            (
                bit_rect.centerx - text.get_width() // 2,
                bit_rect.centery - text.get_height() // 2
            )
        )

        # Cases du masque
        mask_rect = pygame.Rect(
            int(bx),
            mask_y,
            max(1, int(bit_width - 2)),
            35
        )

        pygame.draw.rect(
            surface,
            PANEL_ALT,
            mask_rect,
            border_radius=3
        )

        mask_color = (
            BLUE if i < original_prefix
            else ORANGE if i < current_prefix
            else GREEN
        )

        pygame.draw.rect(
            surface,
            BORDER,
            mask_rect,
            1,
            border_radius=3
        )

        mask_text = SMALL_FONT.render(mask_bits[i], True, mask_color)
        surface.blit(
            mask_text,
            (
                mask_rect.centerx - mask_text.get_width() // 2,
                mask_rect.centery - mask_text.get_height() // 2
            )
        )

    # Séparateurs entre les octets
    for octet in range(1, 4):
        sep_x = int(left + octet * 8 * bit_width - 1)

        pygame.draw.line(
            surface,
            (135, 164, 200),
            (sep_x, address_y - 5),
            (sep_x, mask_y + 36),
            2
        )

    # Curseur orange superposé à la frontière du préfixe
    knob_x = int(left + current_prefix * bit_width)

    # Ligne verticale reliant les deux rangées
    pygame.draw.line(
        surface,
        ORANGE,
        (knob_x, address_y - 10),
        (knob_x, mask_y + 39),
        3
    )

    # Poignée supérieure
    pygame.draw.circle(
        surface,
        ORANGE,
        (knob_x, address_y - 10),
        10
    )

    # Poignée inférieure
    pygame.draw.circle(
        surface,
        ORANGE,
        (knob_x, mask_y + 39),
        10
    )

    # Informations sous la représentation
    info_y = y + 249

    draw_text(
        surface,
        f"Préfixe : /{current_prefix}     -     Masque : {get_subnet_mask(current_prefix)}",
        0, info_y, WHITE, FONT,
        center_x=binary_rect.centerx
    )


    # Légende des couleurs
    legend_y = y + 286

    # Légende : largeur totale des trois groupes
    legend_gap = 20

    items = [
        (BLUE, " bits réseau"),
        (GREEN, " bits hôtes"),
        (ORANGE, " bits empruntés (anciennement hôtes)")
    ]

    rect_width = 29
    text_gap = 1
    item_widths = [
        rect_width + text_gap + SMALL_FONT.size(text)[0]
        for _, text in items
    ]

    total_width = sum(item_widths) + legend_gap * (len(items) - 1)

    # Départ centré dans le panneau
    start_x = binary_rect.centerx - total_width // 2
    current_x = start_x

    for (color, text), item_width in zip(items, item_widths):
        pygame.draw.rect(
            surface,
            color,
            (current_x, legend_y, rect_width, 25),
            border_radius=4
        )

        draw_text(
            surface,
            text,
            current_x + rect_width + text_gap,
            legend_y + 2,
            MUTED,
            SMALL_FONT
        )

        current_x += item_width + legend_gap


# ==================================================
# DÉPLACEMENT DU CURSEUR & 
# ==================================================

def update_prefix_from_mouse(mouse_x):
    global current_prefix, scroll_offset

    left = binary_rect.x + 23
    right = binary_rect.right - 23
    track_width = right - left

    if track_width <= 0:
        return

    # Position de la souris ramenée à un préfixe de 0 à 30
    ratio = (mouse_x - left) / track_width
    ratio = max(0.0, min(1.0, ratio))

    target_prefix = round(ratio * 32)

    # Conserver au moins 2 bits pour les hôtes
    target_prefix = min(target_prefix, 30)

    # Ne jamais revenir avant le préfixe initial
    target_prefix = max(target_prefix, original_prefix)

    if target_prefix != current_prefix:
        current_prefix = target_prefix
        scroll_offset = 0
        rebuild_table()


def get_slider_knob_x():
    left = binary_rect.x + 23
    right = binary_rect.right - 23

    return int(
        left + (right - left) * current_prefix / 32
    )


# ==================================================
# EN-TÊTE DE LA FENÊTRE
# ==================================================

def draw_header(surface):
    pygame.draw.rect(
        surface,
        (12, 27, 49),
        (0, 0, WIDTH, 135)
    )

    pygame.draw.line(
        surface,
        BORDER,
        (0, 48),
        (WIDTH, 48),
        1
    )

    draw_text(
        surface,
        "Calculateur IPv4 - Sous-réseaux",
        0, 12, WHITE, TITLE_FONT,
        center_x=binary_rect.centerx
    )

    draw_text(
        surface,
        "Adresse IPv4 / CIDR :",
        49, 87, WHITE, TITLE_FONT
    )

    pygame.draw.rect(
        surface,
        PANEL_ALT if input_active else PANEL,
        input_rect,
        border_radius=6
    )

    pygame.draw.rect(
        surface,
        BLUE if input_active else BORDER,
        input_rect,
        2,
        border_radius=6
    )

    draw_text(
        surface,
        input_text,
        input_rect.x + 12,
        input_rect.y + 11,
        WHITE,
        TITLE_FONT
    )

    draw_button(
        surface,
        calculate_rect,
        "Calculer"
    )

    status_rect = pygame.Rect(816, 74, 690, 45)

    if error_message:
        draw_text(
            surface,
            error_message,
            816, 123,
            RED,
            SMALL_FONT
        )


'''
Partie 3/3 — Tableau défilant et boucle principale
Elle complète le tableau, ajoute la barre de défilement verticale et gère les interactions à la souris et au clavier.
'''


# ==================================================
# TABLEAU DES SOUS-RÉSEAUX
# ==================================================

def draw_subnet_table(surface):
    global scroll_offset

    x, y, width, height = table_rect
    draw_panel(surface, table_rect)

    draw_text(
        surface,
        "Tableau des sous-réseaux",
        x + 20, y + 12,
        WHITE, TITLE_FONT
    )

    headers = [
        "Adresse réseau",
        "Préfixe",
        "Masque",
        "1er hôte",
        "Dernier hôte",
        "Broadcast",
        "Hôtes attribuables",
    ]

    # Largeurs relatives des colonnes (la colonne Adresse réseau
    # est élargie pour afficher l'adresse décimale et sa version binaire).
    fractions = [0.23, 0.08, 0.15, 0.14, 0.14, 0.14, 0.12]

    # La dernière colonne reste assez large pour son en-tête.
    usable_width = width - 43
    col_widths = [usable_width * f for f in fractions]

    header_y = y + 55
    row_height = 58

    # En-têtes
    col_x = x + 18

    for i, header in enumerate(headers):
        draw_text(
            surface,
            header,
            col_x + 4,
            header_y + 10,
            ORANGE,
            SMALL_FONT
        )
        col_x += col_widths[i]

    pygame.draw.line(
        surface,
        BORDER,
        (x + 18, header_y + 37),
        (x + width - 18, header_y + 37),
        1
    )

    table_top = header_y + 43
    table_bottom = y + height - 44
    visible_height = table_bottom - table_top

    visible_rows = max(1, int(visible_height // row_height))
    max_scroll = max(0, len(table_rows) - visible_rows)

    scroll_offset = max(0, min(scroll_offset, max_scroll))

    # Zone de dessin découpée pour ne pas dépasser du tableau
    clip_rect = pygame.Rect(
        x + 8,
        table_top,
        width - 27,
        visible_height
    )

    previous_clip = surface.get_clip()
    surface.set_clip(clip_rect)

    for visible_index in range(visible_rows):
        row_index = scroll_offset + visible_index

        if row_index >= len(table_rows):
            break

        row = table_rows[row_index]
        row_y = table_top + visible_index * row_height

        # Alternance des couleurs de ligne
        row_color = (
            PANEL_ALT if visible_index % 2
            else (12, 28, 49)
        )

        pygame.draw.rect(
            surface,
            row_color,
            (x + 9, row_y, width - 29, row_height)
        )

        values = [
            row["network"],
            row["prefix"],
            row["mask"],
            row["first_host"],
            row["last_host"],
            row["broadcast"],
            str(row["hosts"]),
        ]

        col_x = x + 18

        # Adresse réseau en décimal, puis en binaire sur la ligne suivante.
        draw_text(
            surface,
            row["network"],
            col_x + 4,
            row_y + 5,
            WHITE,
            SMALL_FONT
        )

        binary_address = get_binary_address(row["network"])
        binary_x = col_x + 4
        binary_y = row_y + 34

        for bit_index, bit in enumerate(binary_address):
            if bit_index < original_prefix:
                bit_color = BLUE
            elif bit_index < current_prefix:
                bit_color = ORANGE
            else:
                bit_color = GREEN

            bit_image = BINARY_TABLE_FONT.render(bit, True, bit_color)
            surface.blit(bit_image, (binary_x, binary_y))
            binary_x += bit_image.get_width()

            # Séparateur entre les octets pour faciliter la lecture.
            if bit_index in (7, 15, 23):
                separator = BINARY_TABLE_FONT.render(".", True, MUTED)
                surface.blit(separator, (binary_x, binary_y))
                binary_x += separator.get_width()

        # Les autres colonnes restent sur une seule ligne.
        col_x += col_widths[0]
        for i, value in enumerate(values[1:], start=1):
            draw_text(
                surface,
                value,
                col_x + 4,
                row_y + 20,
                WHITE,
                SMALL_FONT
            )
            col_x += col_widths[i]

        pygame.draw.line(
            surface,
            BORDER,
            (x + 9, row_y + row_height),
            (x + width - 20, row_y + row_height),
            1
        )

    surface.set_clip(previous_clip)

    # Barre de défilement verticale
    scrollbar_x = x + width - 22
    scrollbar_y = table_top
    scrollbar_height = visible_height

    pygame.draw.rect(
        surface,
        (34, 62, 95),
        (scrollbar_x, scrollbar_y, 10, scrollbar_height),
        border_radius=5
    )

    if table_rows:
        thumb_height = max(
            24,
            int(
                scrollbar_height
                * min(1, visible_rows / len(table_rows))
            )
        )

        thumb_height = min(thumb_height, scrollbar_height)

        scroll_ratio = (
            scroll_offset / max_scroll
            if max_scroll > 0 else 0
        )

        thumb_y = scrollbar_y + int(
            (scrollbar_height - thumb_height) * scroll_ratio
        )

        pygame.draw.rect(
            surface,
            ORANGE,
            (scrollbar_x, thumb_y, 10, thumb_height),
            border_radius=5
        )

    draw_text(
        surface,
        f"{len(table_rows)} sous-réseaux",
        x + 22,
        y + height - 32,
        MUTED,
        SMALL_FONT
    )

    draw_text(
        surface,
        (
            f"Défilement : {scroll_offset + 1}"
            f"/{len(table_rows)}"
            if table_rows else "Aucun sous-réseau"
        ),
        x + 220,
        y + height - 32,
        MUTED,
        SMALL_FONT
    )


# ==================================================
# BOUCLE PRINCIPALE
# ==================================================

async def main():
    global input_text, input_active, scroll_offset

    load_network_from_input()

    running = True
    dragging_slider = False
    dragging_scrollbar = False
    scrollbar_drag_start_y = 0
    scrollbar_drag_start_offset = 0

    while running:
        SCREEN.fill(BG)

        # Géométrie de la barre de défilement
        table_x, table_y, table_w, table_h = table_rect

        header_y = table_y + 55
        row_height = 58
        table_top = header_y + 43
        table_bottom = table_y + table_h - 44
        visible_height = table_bottom - table_top

        visible_rows = max(
            1,
            int(visible_height // row_height)
        )

        max_scroll = max(
            0,
            len(table_rows) - visible_rows
        )

        scrollbar_x = table_x + table_w - 22
        scrollbar_y = table_top
        scrollbar_height = visible_height

        if table_rows:
            thumb_height = max(
                24,
                int(
                    scrollbar_height
                    * min(1, visible_rows / len(table_rows))
                )
            )
            thumb_height = min(thumb_height, scrollbar_height)
        else:
            thumb_height = scrollbar_height

        scroll_ratio = (
            scroll_offset / max_scroll
            if max_scroll > 0 else 0
        )

        thumb_y = scrollbar_y + int(
            (scrollbar_height - thumb_height) * scroll_ratio
        )

        scrollbar_thumb = pygame.Rect(
            scrollbar_x,
            thumb_y,
            10,
            thumb_height
        )

        # Événements
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:

                if event.button == 1:
                    if input_rect.collidepoint(event.pos):
                        input_active = True
                        dragging_slider = False

                    else:
                        input_active = False

                    if calculate_rect.collidepoint(event.pos):
                        load_network_from_input()

                    # Le curseur se trouve directement sur la représentation
                    elif binary_rect.collidepoint(event.pos):
                        knob_x = get_slider_knob_x()

                        # Zone de saisie élargie autour de la poignée orange
                        knob_hitbox = pygame.Rect(
                            knob_x - 20,
                            binary_rect.y + 90,
                            40,
                            140
                        )

                        if knob_hitbox.collidepoint(event.pos):
                            dragging_slider = True
                            update_prefix_from_mouse(event.pos[0])

                        else:
                            # Cliquer ailleurs dans la représentation permet
                            # également de positionner directement le curseur.
                            dragging_slider = True
                            update_prefix_from_mouse(event.pos[0])

                    # Défilement en cliquant sur la poignée
                    elif scrollbar_thumb.collidepoint(event.pos):
                        dragging_scrollbar = True
                        scrollbar_drag_start_y = event.pos[1]
                        scrollbar_drag_start_offset = scroll_offset

                    # Cliquer dans la piste déplace la poignée
                    elif (
                        table_rect.collidepoint(event.pos)
                        and event.pos[0] >= scrollbar_x - 5
                    ):
                        if event.pos[1] < thumb_y:
                            scroll_offset = max(
                                0, scroll_offset - visible_rows
                            )
                        elif event.pos[1] > thumb_y + thumb_height:
                            scroll_offset = min(
                                max_scroll,
                                scroll_offset + visible_rows
                            )

                elif event.button == 4:
                    if table_rect.collidepoint(event.pos):
                        scroll_offset = max(0, scroll_offset - 3)

                elif event.button == 5:
                    if table_rect.collidepoint(event.pos):
                        scroll_offset = min(
                            max_scroll,
                            scroll_offset + 3
                        )

            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    dragging_slider = False
                    dragging_scrollbar = False

            elif event.type == pygame.MOUSEMOTION:

                if dragging_slider:
                    update_prefix_from_mouse(event.pos[0])

                if dragging_scrollbar and max_scroll > 0:
                    delta_y = event.pos[1] - scrollbar_drag_start_y

                    available_track = max(
                        1, scrollbar_height - thumb_height
                    )

                    scroll_delta = round(
                        delta_y / available_track * max_scroll
                    )

                    scroll_offset = max(
                        0,
                        min(
                            max_scroll,
                            scrollbar_drag_start_offset + scroll_delta
                        )
                    )

            elif event.type == pygame.KEYDOWN:

                if input_active:
                    if event.key == pygame.K_RETURN:
                        load_network_from_input()
                        input_active = False

                    elif event.key == pygame.K_BACKSPACE:
                        input_text = input_text[:-1]

                    elif event.key == pygame.K_ESCAPE:
                        input_active = False

                    elif event.unicode and event.unicode.isprintable():
                        input_text += event.unicode

                else:
                    if event.key == pygame.K_UP:
                        scroll_offset = max(0, scroll_offset - 1)

                    elif event.key == pygame.K_DOWN:
                        scroll_offset = min(
                            max_scroll,
                            scroll_offset + 1
                        )

                    elif event.key == pygame.K_HOME:
                        scroll_offset = 0

                    elif event.key == pygame.K_END:
                        scroll_offset = max_scroll

        # Dessin de l'interface
        draw_header(SCREEN)
        draw_binary_visual(SCREEN)
        draw_subnet_table(SCREEN)

        pygame.display.flip()
        CLOCK.tick(60)
        await asyncio.sleep(0)
    '''pygame.quit()
    sys.exit()'''


if __name__ == "__main__":
    asyncio.run(main())

