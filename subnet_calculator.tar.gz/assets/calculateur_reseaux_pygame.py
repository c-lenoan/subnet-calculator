import ipaddress
import math
import sys
import pygame

# ------------------------------------------------------------
# Calculateur pédagogique IPv4 / CIDR avec curseur de sous-réseautage
# Dépendance : pygame (pip install pygame)
# ------------------------------------------------------------

pygame.init()

WIDTH, HEIGHT = 1400, 900
MIN_WIDTH, MIN_HEIGHT = 1050, 700
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption("Laboratoire IPv4 — Réseaux et sous-réseaux")
clock = pygame.time.Clock()

# Palette
BG = (246, 248, 251)
PANEL = (255, 255, 255)
TEXT = (31, 41, 55)
MUTED = (100, 116, 139)
BORDER = (210, 218, 228)
BLUE = (191, 219, 254)       # Net-ID initiale
BLUE_DARK = (37, 99, 235)
ORANGE = (254, 215, 170)     # bits empruntés
ORANGE_DARK = (217, 119, 6)
GREEN = (187, 247, 208)      # Host-ID restante
GREEN_DARK = (22, 163, 74)
RED = (220, 38, 38)
HEADER = (232, 238, 246)
ROW_ALT = (242, 246, 251)
WHITE = (255, 255, 255)
ERROR_BG = (254, 242, 242)
ERROR_FG = (185, 28, 28)

FONT = pygame.font.SysFont("dejavusans", 17)
SMALL = pygame.font.SysFont("dejavusans", 14)
TINY = pygame.font.SysFont("dejavusans", 12)
BOLD = pygame.font.SysFont("dejavusans", 17, bold=True)
TITLE = pygame.font.SysFont("dejavusans", 25, bold=True)
MONO = pygame.font.SysFont("dejavusansmono", 16)
MONO_SMALL = pygame.font.SysFont("dejavusansmono", 13)

# Etat de l'application
cidr_text = "192.168.10.0/24"
input_active = False
input_rect = pygame.Rect(0, 0, 280, 38)
validate_rect = pygame.Rect(0, 0, 110, 38)
network = ipaddress.ip_network(cidr_text, strict=False)
initial_prefix = network.prefixlen
current_prefix = initial_prefix
dragging = False
cursor_x = 0
message = ""
message_is_error = False
scroll_rows = 0
MAX_ROWS = 4096

# Géométrie recalculée selon la taille de la fenêtre
layout = {}


def draw_text(surface, text, x, y, font=FONT, color=TEXT, anchor="topleft"):
    image = font.render(str(text), True, color)
    rect = image.get_rect()
    setattr(rect, anchor, (int(x), int(y)))
    surface.blit(image, rect)
    return rect


def draw_panel(rect, title=None):
    pygame.draw.rect(screen, PANEL, rect, border_radius=10)
    pygame.draw.rect(screen, BORDER, rect, width=1, border_radius=10)
    if title:
        draw_text(screen, title, rect.x + 16, rect.y + 12, BOLD)


def fmt_int(n):
    return f"{n:,}".replace(",", " ")


def binary32(value):
    return f"{int(value):032b}"


def set_network(text):
    global network, initial_prefix, current_prefix, message
    global message_is_error, scroll_rows, dragging
    try:
        parsed = ipaddress.ip_network(text.strip(), strict=False)
        if parsed.version != 4:
            raise ValueError("Seules les adresses IPv4 sont prises en charge.")
        network = parsed
        initial_prefix = parsed.prefixlen
        current_prefix = initial_prefix
        scroll_rows = 0
        dragging = False
        message = (
            f"Réseau chargé : {network.network_address}/{network.prefixlen}. "
            "La frontière démarre à la limite du réseau initial."
        )
        message_is_error = False
    except ValueError as exc:
        message = str(exc)
        message_is_error = True


def compute_layout():
    global layout, input_rect, validate_rect
    w, h = screen.get_size()
    margin = 18
    content_w = w - 2 * margin

    header_h = 78
    input_y = 82
    input_h = 82
    binary_y = 174
    binary_h = 280
    info_y = 464
    info_h = 72
    table_y = 546
    table_h = h - table_y - 18

    layout = {
        "w": w, "h": h, "margin": margin,
        "header": pygame.Rect(margin, 12, content_w, 58),
        "input": pygame.Rect(margin, input_y, content_w, input_h),
        "binary": pygame.Rect(margin, binary_y, content_w, binary_h),
        "info": pygame.Rect(margin, info_y, content_w, info_h),
        "table": pygame.Rect(margin, table_y, content_w, table_h),
    }

    input_rect = pygame.Rect(margin + 190, input_y + 31, 300, 38)
    validate_rect = pygame.Rect(input_rect.right + 12, input_y + 31, 115, 38)

    b = layout["binary"]
    bit_x = b.x + 185
    bit_right = b.right - 24
    bit_w = (bit_right - bit_x) / 32
    layout["bit_x"] = bit_x
    layout["bit_right"] = bit_right
    layout["bit_w"] = bit_w
    layout["bit_y_ip"] = b.y + 83
    layout["bit_y_mask"] = b.y + 137
    layout["cursor_y_top"] = b.y + 55
    layout["cursor_y_bottom"] = b.y + 190
    layout["table_header_y"] = table_y + 42
    layout["table_rows_top"] = table_y + 69
    layout["row_h"] = 27


def draw_button(rect, label, enabled=True):
    fill = BLUE_DARK if enabled else (160, 174, 192)
    pygame.draw.rect(screen, fill, rect, border_radius=7)
    image = BOLD.render(label, True, WHITE)
    screen.blit(image, image.get_rect(center=rect.center))


def draw_input_panel():
    r = layout["input"]
    draw_panel(r, "Réseau IPv4 de départ")
    draw_text(screen, "Adresse IP / CIDR :", r.x + 18, r.y + 42, FONT)
    pygame.draw.rect(screen, WHITE, input_rect, border_radius=6)
    pygame.draw.rect(screen, BLUE_DARK if input_active else BORDER,
                     input_rect, width=2 if input_active else 1, border_radius=6)
    shown = cidr_text
    # Garde le texte lisible si l'utilisateur saisit une longue chaîne.
    draw_text(screen, shown, input_rect.x + 10, input_rect.y + 9, MONO)
    draw_button(validate_rect, "Valider")
    draw_text(
        screen, "Exemple : 192.168.10.0/24",
        validate_rect.right + 16, input_rect.y + 11, SMALL, MUTED
    )


def draw_binary_panel():
    r = layout["binary"]
    draw_panel(r, "Représentation binaire — faites glisser la poignée rouge")
    draw_text(screen, "Adresse réseau", r.x + 16, layout["bit_y_ip"] - 10,
              SMALL, TEXT, "midleft")
    draw_text(screen, "Masque", r.x + 16, layout["bit_y_mask"] - 10,
              SMALL, TEXT, "midleft")

    ip_bits = binary32(network.network_address)
    current_mask = ipaddress.ip_network(f"0.0.0.0/{current_prefix}").netmask
    mask_bits = binary32(current_mask)
    x0 = layout["bit_x"]
    bw = layout["bit_w"]

    for row_index, bits in enumerate((ip_bits, mask_bits)):
        cy = layout["bit_y_ip"] if row_index == 0 else layout["bit_y_mask"]
        for i, bit in enumerate(bits):
            x = x0 + i * bw
            if i < initial_prefix:
                color = BLUE
            elif i < current_prefix:
                color = ORANGE
            else:
                color = GREEN
            cell = pygame.Rect(round(x), round(cy - 17), max(1, math.ceil(bw)), 34)
            pygame.draw.rect(screen, color, cell)
            pygame.draw.rect(screen, WHITE, cell, width=1)
            draw_text(screen, bit, x + bw / 2, cy, MONO_SMALL, TEXT, "center")
            if i in (7, 15, 23):
                sep_x = x + bw
                pygame.draw.line(screen, (126, 138, 153),
                                 (sep_x, cy - 22), (sep_x, cy + 23), 2)

    # Octets en décimal sous les bits
    for row_index, value in enumerate((network.network_address, network.netmask)):
        y = layout["bit_y_ip"] + 25 if row_index == 0 else layout["bit_y_mask"] + 25
        octets = str(value).split(".")
        for j, octet in enumerate(octets):
            center_x = x0 + (j * 8 + 4) * bw
            draw_text(screen, octet, center_x, y, TINY, MUTED, "center")

    # Curseur / frontière mobile
    x = x0 + current_prefix * bw
    top = layout["cursor_y_top"]
    bottom = layout["cursor_y_bottom"]
    pygame.draw.line(screen, RED, (round(x), top), (round(x), bottom), 4)
    handle = pygame.Rect(round(x - 9), top - 5, 18, 18)
    pygame.draw.rect(screen, RED, handle, border_radius=5)
    pygame.draw.polygon(
        screen, RED,
        [(x - 8, bottom - 2), (x + 8, bottom - 2), (x, bottom + 10)]
    )
    draw_text(screen, f"/{current_prefix}", x, bottom + 15, BOLD, RED, "midtop")

    # Zones Net-ID / Subnet-ID / Host-ID
    legend_y = r.bottom - 35
    legend = [
        (BLUE_DARK, f"Net-ID initiale : {initial_prefix} bits"),
        (ORANGE_DARK, f"Subnet-ID : {current_prefix - initial_prefix} bits empruntés"),
        (GREEN_DARK, f"Host-ID restante : {32 - current_prefix} bits"),
    ]
    lx = r.x + 18
    for color, label in legend:
        pygame.draw.rect(screen, color, (lx, legend_y + 2, 13, 13), border_radius=3)
        text_img = SMALL.render(label, True, TEXT)
        screen.blit(text_img, (lx + 20, legend_y))
        lx += 20 + text_img.get_width() + 28


def draw_info_panel():
    r = layout["info"]
    draw_panel(r)
    borrowed = current_prefix - initial_prefix
    host_bits = 32 - current_prefix
    subnet_count = 2 ** borrowed
    if current_prefix == 32:
        hosts = 1
    elif current_prefix == 31:
        hosts = 2
    else:
        hosts = max(0, 2 ** host_bits - 2)

    draw_text(screen, f"Réseau de départ : {network.network_address}/{initial_prefix}",
              r.x + 16, r.y + 12, BOLD)
    draw_text(screen, f"Masque actuel : /{current_prefix} ({network.netmask if current_prefix == initial_prefix else ipaddress.ip_network('0.0.0.0/' + str(current_prefix)).netmask})",
              r.x + 16, r.y + 39, SMALL)
    x2 = r.x + 440
    draw_text(screen, f"Sous-réseaux : {fmt_int(subnet_count)}",
              x2, r.y + 12, BOLD, BLUE_DARK)
    draw_text(screen, f"Hôtes utilisables / sous-réseau : {fmt_int(hosts)}",
              x2, r.y + 39, SMALL, GREEN_DARK)
    x3 = r.x + 850
    draw_text(screen, f"Bits empruntés : {borrowed}",
              x3, r.y + 12, BOLD, ORANGE_DARK)
    draw_text(screen, f"Bits hôtes restants : {host_bits}",
              x3, r.y + 39, SMALL, GREEN_DARK)


def host_range(subnet):
    first = subnet.network_address
    last = subnet.broadcast_address
    if subnet.prefixlen == 32:
        return str(first), str(last), 1
    if subnet.prefixlen == 31:
        return str(first), str(last), 2
    return str(first + 1), str(last - 1), max(0, subnet.num_addresses - 2)


def draw_table_panel():
    r = layout["table"]
    draw_panel(r, "Tableau des réseaux / sous-réseaux")
    cols = [
        ("Adresse réseau", 0.00, 0.145),
        ("CIDR", 0.145, 0.06),
        ("Masque décimal", 0.205, 0.14),
        ("Première adresse", 0.345, 0.15),
        ("Dernière adresse", 0.495, 0.15),
        ("Broadcast", 0.645, 0.15),
        ("Adresses utilisables", 0.795, 0.205),
    ]
    inner_x = r.x + 12
    inner_w = r.width - 24
    hy = layout["table_header_y"]
    row_h = layout["row_h"]

    pygame.draw.rect(screen, HEADER,
                     (inner_x, hy, inner_w, row_h), border_radius=4)
    for title, start, width in cols:
        draw_text(screen, title, inner_x + start * inner_w + 7,
                  hy + row_h // 2, SMALL, TEXT, "midleft")

    prefix = current_prefix
    total = 2 ** (prefix - initial_prefix)
    max_visible = max(1, (r.bottom - 12 - layout["table_rows_top"]) // row_h)
    display_limit = min(total, MAX_ROWS, max_visible + scroll_rows)
    start_index = min(scroll_rows, max(0, min(total, MAX_ROWS) - max_visible))

    # subnets() itère dans l'ordre, en commençant par le réseau initial.
    # L'index de départ est converti en adresse réseau directement pour éviter
    # de parcourir toutes les lignes précédentes lors du défilement.
    block_size = 2 ** (32 - prefix)
    network_start_int = int(network.network_address)
    first_i = start_index
    last_i = min(total, MAX_ROWS, start_index + max_visible)

    for row_index, i in enumerate(range(first_i, last_i)):
        y = layout["table_rows_top"] + row_index * row_h
        if y + row_h > r.bottom - 8:
            break
        if row_index % 2 == 1:
            pygame.draw.rect(screen, ROW_ALT, (inner_x, y, inner_w, row_h))
        net_addr = ipaddress.IPv4Address(network_start_int + i * block_size)
        subnet = ipaddress.ip_network(f"{net_addr}/{prefix}", strict=True)
        first, last, usable = host_range(subnet)
        values = [
            str(subnet.network_address), f"/{prefix}", str(subnet.netmask),
            first, last, str(subnet.broadcast_address), fmt_int(usable)
        ]
        for value, (title, start, width) in zip(values, cols):
            draw_text(screen, value, inner_x + start * inner_w + 7,
                      y + row_h // 2, TINY, TEXT, "midleft")

    visible_count = min(total, MAX_ROWS)
    footer_y = r.bottom - 18
    if total > MAX_ROWS:
        footer = f"Affichage limité aux {fmt_int(MAX_ROWS)} premiers sous-réseaux sur {fmt_int(total)}."
    else:
        footer = f"{fmt_int(total)} sous-réseau(x) au total."
    draw_text(screen, footer, r.x + 14, footer_y, TINY, MUTED)


def draw_status():
    global message
    if not message:
        return
    w, h = screen.get_size()
    color = ERROR_FG if message_is_error else MUTED
    # Message compact sous le bandeau principal.
    draw_text(screen, message, 20, 72, SMALL, color)


def render():
    screen.fill(BG)
    compute_layout()

    header = layout["header"]
    draw_text(screen, "Laboratoire IPv4", header.x, header.y, TITLE)
    draw_text(screen, "Comprendre Net-ID, Subnet-ID et Host-ID en déplaçant une frontière bit par bit",
              header.x, header.y + 34, SMALL, MUTED)

    draw_input_panel()
    draw_binary_panel()
    draw_info_panel()
    draw_table_panel()
    draw_status()
    pygame.display.flip()


def cursor_hit_test(pos):
    x, y = pos
    cx = layout["bit_x"] + current_prefix * layout["bit_w"]
    return abs(x - cx) <= 13 and layout["cursor_y_top"] - 12 <= y <= layout["cursor_y_bottom"] + 12


def update_cursor_from_mouse(x):
    global current_prefix, scroll_rows
    bw = layout["bit_w"]
    proposed = round((x - layout["bit_x"]) / bw)
    proposed = max(initial_prefix, min(32, proposed))
    if proposed != current_prefix:
        current_prefix = proposed
        scroll_rows = 0


def main():
    global screen, WIDTH, HEIGHT, input_active, cidr_text, dragging
    global scroll_rows, message, message_is_error

    running = True
    while running:
        clock.tick(60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.VIDEORESIZE:
                WIDTH = max(MIN_WIDTH, event.w)
                HEIGHT = max(MIN_HEIGHT, event.h)
                screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if input_rect.collidepoint(event.pos):
                        input_active = True
                    else:
                        input_active = False

                    if validate_rect.collidepoint(event.pos):
                        set_network(cidr_text)
                    else:
                        compute_layout()
                        if cursor_hit_test(event.pos):
                            dragging = True
                            update_cursor_from_mouse(event.pos[0])

                elif event.button == 4:
                    # Roulette vers le haut : remonter dans la liste
                    compute_layout()
                    if layout["table"].collidepoint(event.pos):
                        scroll_rows = max(0, scroll_rows - 3)
                elif event.button == 5:
                    # Roulette vers le bas
                    compute_layout()
                    if layout["table"].collidepoint(event.pos):
                        max_total = min(2 ** (current_prefix - initial_prefix), MAX_ROWS)
                        max_visible = max(1, (layout["table"].bottom - 12 - layout["table_rows_top"]) // layout["row_h"])
                        scroll_rows = min(max(0, max_total - max_visible), scroll_rows + 3)

            elif event.type == pygame.MOUSEMOTION:
                if dragging:
                    compute_layout()
                    update_cursor_from_mouse(event.pos[0])

            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    dragging = False

            elif event.type == pygame.KEYDOWN:
                if input_active:
                    if event.key == pygame.K_RETURN:
                        set_network(cidr_text)
                        input_active = False
                    elif event.key == pygame.K_BACKSPACE:
                        cidr_text = cidr_text[:-1]
                    elif event.key == pygame.K_ESCAPE:
                        input_active = False
                    else:
                        if event.unicode and event.unicode.isprintable():
                            if len(cidr_text) < 40:
                                cidr_text += event.unicode
                else:
                    # Clavier : flèches gauche/droite d'un bit, gauche bornée au départ.
                    if event.key == pygame.K_RIGHT:
                        current_prefix = min(32, current_prefix + 1)
                        scroll_rows = 0
                    elif event.key == pygame.K_LEFT:
                        current_prefix = max(initial_prefix, current_prefix - 1)
                        scroll_rows = 0

        render()

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
